--Question 1

CREATE TABLE KAYAKS (
    kayak_id CHAR(6) NOT NULL,
    kayak_type VARCHAR2(100) NOT NULL,
    kayak_model VARCHAR2(100) NOT NULL,
    manufacturer VARCHAR2(100) NOT NULL,
    CONSTRAINT pk_KAYAKS PRIMARY KEY(kayak_id)
);

CREATE TABLE CUSTOMER (
    cust_id VARCHAR2(5) NOT NULL,
    cust_fname VARCHAR2(50) NOT NULL,
    cust_sname VARCHAR2(50) NOT NULL,
    cust_address VARCHAR2(100) NOT NULL,
    cust_contact VARCHAR2(15) NOT NULL,
    CONSTRAINT pk_CUSTOMER PRIMARY KEY(cust_id)
);

CREATE TABLE UPGRADES (
    upgrade_id INT NOT NULL,
    upgrade_work VARCHAR2(100) NOT NULL,
    upgrade_date DATE NOT NULL,
    upgrade_hrs NUMBER NOT NULL,
    CONSTRAINT pk_UPGRADES PRIMARY KEY(upgrade_id)
);

CREATE TABLE KAYAK_UPGRADES (
    kayak_upgrade_num NUMBER,
    kayak_upgrade_date DATE NOT NULL,
    kayak_upgrade_amt NUMBER NOT NULL,
    kayak_id CHAR(6) NOT NULL,
    cust_id VARCHAR2(5) NOT NULL,
    upgrade_id INT NOT NULL,
    CONSTRAINT PK_KAYAK_UPGRADES PRIMARY KEY(kayak_upgrade_num),
    CONSTRAINT FK_KAYAKS FOREIGN KEY (kayak_id) REFERENCES KAYAKS(kayak_id),
    CONSTRAINT FK_CUSTOMER FOREIGN KEY (cust_id) REFERENCES CUSTOMER(cust_id),
    CONSTRAINT FK_UPGRADES FOREIGN KEY (upgrade_id) REFERENCES UPGRADES(upgrade_id)
);

-- Inserting sample data into tables

INSERT ALL
         INTO KAYAKS VALUES ('12345', 'Single Seater', 'K100', 'Feel Free')
         INTO KAYAKS VALUES ('54321', 'Tandem Seater', 'J55', 'Roamer')
         INTO KAYAKS VALUES ('78945', 'Fishing Kayak', 'H9000', 'Wavesport')
         INTO KAYAKS VALUES ('98754', 'Hobie Kayak', 'A450', 'Gemini')
         INTO KAYAKS VALUES ('55311', 'Canadian Style', 'L920', 'Surge')
         SELECT* FROM DUAL;

INSERT ALL
          INTO CUSTOMER VALUES ('C115', 'Jeff', 'Willis', '3 Main Road', '0821253659')
          INTO CUSTOMER VALUES ('C116', 'Andre', 'Watson', '13 Cape Road', '0769658547')
          INTO CUSTOMER VALUES ('C117', 'Wallis', 'Smith', '3 Mountain Road', '0863256574')
          INTO CUSTOMER VALUES ('C118', 'Alex', 'Hanson', '8 Circle Road', '0762356587')
          INTO CUSTOMER VALUES ('C119', 'Bob', 'Bitterhout', '15 Main Road', '0821235258')
          INTO CUSTOMER VALUES ('C120', 'Thando', 'Zolani', '88 Summer Road', '084754125')
          SELECT* FROM DUAL;

INSERT ALL
          INTO UPGRADES VALUES ('1', 'Sonar Device','15-JUL-22', '5')
          INTO UPGRADES VALUES ('2', 'Padded Seats','18-JUL-22', '3')
          INTO UPGRADES VALUES ('3', 'GoPro Camera Mount','19-JUL-22','10')
          SELECT* FROM DUAL;

INSERT ALL
          INTO KAYAK_UPGRADES VALUES ('101','27-JUL-19', '75','98754', 'C121','3')
          INTO KAYAK_UPGRADES VALUES ('102','20-JUL-19', '30', '12345', 'C120', '2')
          INTO KAYAK_UPGRADES VALUES ('103','23-JUL-19', '75', '55311', 'C119', '1')
          INTO KAYAK_UPGRADES VALUES ('104','17-JUL-19', '50', '54321', 'C117','1')
          INTO KAYAK_UPGRADES VALUES ('105','19-JUL-19','30', '12345', 'C122', '2')
          SELECT* FROM DUAL;
          
--Question 3

CREATE USER Tshepo_Mya IDENTIFIED BY tmphoabc2023;
GRANT SELECT ANY TABLE TO Tshepo_Mya;
GRANT INSERT ANY TABLE TO Tshepo_Mya;

--Question 4
SELECT ku.kayak_id, ku.cust_id, ku.upgrade_hrs, ku.kayak_upgrade_amt,
       ku.upgrade_hrs * ku.kayak_upgrade_amt AS total
FROM KAYAK_UPGRADES ku;

---Question 5
SELECT c.cust_fname || ' ' || c.cust_sname AS customer_name, k.kayak_type,
       ku.upgrade_hrs, u.upgrade_work, ku.kayak_upgrade_amt
FROM CUSTOMER c
JOIN KAYAK_UPGRADES ku ON c.cust_id = ku.cust_id
JOIN KAYAKS k ON ku.kayak_id = k.kayak_id
JOIN UPGRADES u ON ku.upgrade_id = u.upgrade_id;

--Question 6
DECLARE
    CURSOR upgrade_cursor IS
        SELECT ku.cust_id, u.upgrade_work, ku.kayak_upgrade_amt
        FROM KAYAK_UPGRADES ku
        JOIN UPGRADES u ON ku.upgrade_id = u.upgrade_id
        WHERE ku.kayak_upgrade_amt > 50;
BEGIN
    FOR upgrade_rec IN upgrade_cursor LOOP
        DBMS_OUTPUT.PUT_LINE('CUSTOMER ID: ' || upgrade_rec.cust_id || ', ' ||
                             'UPGRADE WORK: ' || upgrade_rec.upgrade_work || ', ' ||
                             'UPGRADE AMOUNT: R ' || upgrade_rec.kayak_upgrade_amt);
    END LOOP;
END;
/

--Question 7
DECLARE
    v_discount NUMBER := 0.1; -- 10% discount
BEGIN
    FOR 
    upgrade_rec IN (SELECT c.cust_fname || ' ' || c.cust_sname AS customer_name,k.kayak_type,u.upgrade_work,ku.kayak_upgrade_date,ku.kayak_upgrade_amt,
      CASE
      WHEN c.cust_id = 'C121' THEN ku.kayak_upgrade_amt * v_discount
      ELSE 0
      END AS discount_amt
      FROM CUSTOMER c
      INNER JOIN KAYAK_UPGRADES ku ON c.cust_id = ku.cust_id
      INNER JOIN KAYAKS k ON ku.kayak_id = k.kayak_id
      INNER JOIN UPGRADES u ON ku.upgrade_id = u.upgrade_id) LOOP
        dmbs_output.put_line('CUSTOMER: ' || upgrade_rec.customer_name || ', ' ||'KAYAK TYPE: ' || upgrade_rec.kayak_type || ', ' ||'UPGRADE WORK: ' || upgrade_rec.upgrade_work || ', ' ||
                             'UPGRADE DATE: ' || TO_CHAR(upgrade_rec.kayak_upgrade_date, 'DD-MON-YY') || ', ' ||
                             'UPGRADE AMT: R ' || upgrade_rec.kayak_upgrade_amt || ', ' ||
                             'DISCOUNT AMT: R ' || upgrade_rec.discount_amt);
    END LOOP;
END;
/

--Question 8
 CREATE VIEW vwCustUpgrades AS
SELECT c.cust_fname || ', ' || c.cust_sname AS customer,k.kayak_type,u.upgrade_work,c.cust_contact
FROM CUSTOMER c
  INNER JOIN KAYAK_UPGRADES ku ON c.cust_id = ku.cust_id
  INNER JOIN KAYAKS k ON ku.kayak_id = k.kayak_id
WHERE UPPER(c.cust_address) LIKE '%SUMMER%';